"""Import the user's named WAVs without changing speech speed or overwriting sources."""
import argparse, hashlib, json, re, subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('source',type=Path);a=p.parse_args()
root=Path(__file__).resolve().parents[1]; dest=root/'public/assets/hongqiao/cinema/audio';dest.mkdir(parents=True,exist_ok=True)
ids=['intro_01','intro_03','intro_04','intro_05','intro_06','intro_07','intro_08a','intro_08b','intro_08c','intro_09','ending_01','ending_02','ending_03','amb_river','amb_market','sfx_pole_brace','sfx_rope_throw','sfx_rope_handle','sfx_mast_lower','sfx_pole_stow','sfx_ship_pass']
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
manifest={'version':1,'source':'晓梦提供的剪映配音与音效，2026-09-16','processing':'48 kHz PCM; voice leading silence only; no speed change; conservative gain and peak limiting','files':{}}
for id in ids:
    matches=list(a.source.rglob(id+'.wav'))
    if len(matches)!=1:raise ValueError(f'{id}: expected one source, found {len(matches)}')
    source=matches[0];analysis=subprocess.run(['ffmpeg','-hide_banner','-i',str(source),'-af','silencedetect=noise=-45dB:d=0.06,volumedetect','-f','null','-'],capture_output=True,text=True,check=True).stderr
    mean=float(re.search(r'mean_volume: ([-\d.]+)',analysis)[1]);peak=float(re.search(r'max_volume: ([-\d.]+)',analysis)[1])
    voice=id.startswith(('intro_','ending_'));trim=0
    leading=re.search(r'silence_start: 0\n.*?silence_end: ([\d.]+)',analysis)
    if voice and leading:trim=max(0,float(leading[1])-.045)
    gain=min(-21-mean,-3-peak) if voice else (-32-mean if id=='amb_market' else 10 if id=='amb_river' else -8-peak)
    filters=f'atrim=start={trim},asetpts=PTS-STARTPTS,volume={gain}dB,alimiter=limit={0.708 if voice else 0.398}:level=false:latency=true,afade=t=in:d=0.003'
    output=dest/(id+'.wav')
    subprocess.run(['ffmpeg','-v','error','-y','-i',str(source),'-af',filters,'-ar','48000','-ac','1' if voice else '2','-c:a','pcm_s16le',str(output)],check=True)
    duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(output)],text=True))
    manifest['files'][id]={'file':output.name,'sha256':sha(output),'sourceSha256':sha(source),'sourceFile':str(source.relative_to(a.source)),'duration':duration,'gainDb':round(gain,3),'leadingTrimSeconds':round(trim,6),'channels':1 if voice else 2,'sampleRate':48000}
(dest/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(f'Imported {len(ids)} clips, {sum(p.stat().st_size for p in dest.glob("*.wav"))/1048576:.2f} MiB')
