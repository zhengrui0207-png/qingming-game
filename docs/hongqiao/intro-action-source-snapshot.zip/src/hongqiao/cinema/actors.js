import * as THREE from 'three';
import actions from './actions.json';
import {sampleRole,clamp} from './timeline.js';
const V=(a)=>new THREE.Vector3(...a);
// Dedicated key poses from Blender + deterministic hand IK to the authored prop contact points.
export function createPerformer(library,id,parent,position,yaw=0){
 const visual=library.spawn('npc_hq_zhou');if(!visual)throw Error('Existing QMSH-22 boatman is unavailable');
 const root=visual.root;root.name=id;root.position.fromArray(position);root.rotation.y=yaw;parent.add(root);
 const bones=new Map(),base=new Map();root.traverse(o=>{if(o.isBone){bones.set(o.name,o);base.set(o,o.quaternion.clone());}if(o.name==='QMSH22_bamboo_pole')o.visible=false;if(o.isMesh){o.frustumCulled=false;o.castShadow=true;}});
 const chains=actions.armChains.map(names=>names.map(n=>bones.get(THREE.PropertyBinding.sanitizeNodeName(n)))).filter(c=>c.every(Boolean));
 if(chains.length!==2)throw Error('Cinematic performer needs both authored arm chains');
 const head=bones.get('tripoHead_1'),spine=bones.get('tripoSpine_1');
 // The source rig ends at the wrists. Calibrated palm sockets place the line in the hand,
 // rather than driving a wrist joint onto the centre of a prop.
 const sockets=chains.map((chain,i)=>{const socket=new THREE.Object3D();socket.name=id+'_palm_'+i;socket.position.fromArray(i===0?[-.020,.052,.003]:[-.021,.022,.022]);chain[2].add(socket);return socket;});
 let gripTargets=[];
 const gripAxes=[V([.95,-.08,.3]).normalize(),V([.39587,-.22954,.88916])];
 function rotateTo(joint,from,to){
  const parent=joint.parent.getWorldQuaternion(new THREE.Quaternion());
  joint.quaternion.premultiply(parent.clone().invert().multiply(new THREE.Quaternion().setFromUnitVectors(from.normalize(),to.normalize())).multiply(parent));
 }
 function aim(chain,target,i,direction){
  const wrist=chain[2],palm=sockets[i],world=(node)=>node.getWorldPosition(new THREE.Vector3());
  for(let repeat=0;repeat<6;repeat++){
   root.updateMatrixWorld(true);
   if(direction)rotateTo(wrist,gripAxes[i].clone().applyQuaternion(wrist.getWorldQuaternion(new THREE.Quaternion())),V(direction));
   root.updateMatrixWorld(true);
   const shoulder=world(chain[0]),elbow=world(chain[1]),hand=world(wrist),offset=world(palm).sub(hand),goal=target.clone().sub(offset);
   const upper=shoulder.distanceTo(elbow),lower=elbow.distanceTo(hand),axis=goal.clone().sub(shoulder),distance=THREE.MathUtils.clamp(axis.length(),Math.abs(upper-lower)+.001,upper+lower-.005);axis.normalize();
   const along=(upper*upper-lower*lower+distance*distance)/(2*distance),height=Math.sqrt(Math.max(0,upper*upper-along*along));
   const bend=V([i===0?.7:-.7,-1,-.25]).applyQuaternion(root.getWorldQuaternion(new THREE.Quaternion()));bend.addScaledVector(axis,-bend.dot(axis)).normalize();
   const desiredElbow=shoulder.clone().addScaledVector(axis,along).addScaledVector(bend,height);
   rotateTo(chain[0],elbow.clone().sub(shoulder),desiredElbow.sub(shoulder));root.updateMatrixWorld(true);
   const elbowNow=world(chain[1]);rotateTo(chain[1],world(wrist).sub(elbowNow),goal.clone().sub(elbowNow));
  }
  root.updateMatrixWorld(true);
 }
 function pose(role,phase=0,targets=[],direction=null){
  for(const [b,q] of base)b.quaternion.copy(q);
  const [lean,turn,reach]=sampleRole(actions.tracks[role]??actions.tracks.brace,clamp(phase));
  const rotateWorld=(bone,axis,angle)=>{if(!bone)return;const parent=bone.parent.getWorldQuaternion(new THREE.Quaternion());bone.quaternion.premultiply(parent.clone().invert().multiply(new THREE.Quaternion().setFromAxisAngle(axis,angle)).multiply(parent));};
  if(role==='tow')rotateWorld(spine,new THREE.Vector3(0,1,0),-1.35);
  rotateWorld(spine,new THREE.Vector3(1,0,0).applyQuaternion(root.getWorldQuaternion(new THREE.Quaternion())),lean);rotateWorld(head,new THREE.Vector3(0,1,0),role==='tow'?-.4-.9*turn:turn);
  const defaults=[[.25,1.2+reach*.2,.14+reach*.18],[-.25,1.2+reach*.2,.14+reach*.18]];
  if(role==='tow'&&phase<.5){const stride=Math.sin(phase*8*Math.PI)*.28;for(const [name,sign] of [['tripo1_Right_Limb_0',1],['tripo0_Left_Limb_0',-1]])bones.get(name)?.rotateZ(sign*stride);}
  root.updateMatrixWorld(true);
  gripTargets=targets.map(V);for(let i=0;i<chains.length;i++)aim(chains[i],targets[i]?V(targets[i]):root.localToWorld(V(defaults[i])),i,direction);
 }
 return {root,pose,hand:i=>sockets[i]?.getWorldPosition(new THREE.Vector3()),getState:()=>({id,sourceAsset:visual.asset.id,position:root.getWorldPosition(new THREE.Vector3()).toArray(),armChains:chains.length,hands:sockets.map(s=>s.getWorldPosition(new THREE.Vector3()).toArray()),gripErrors:gripTargets.map((t,i)=>sockets[i].getWorldPosition(new THREE.Vector3()).distanceTo(t))})};
}
