"""Author role-specific cue curves and skeletal preview on the existing QMSH-22 rig."""
import bpy,json,math,os
R='/Users/zhengrui/Documents/ChatGPT/3d 打印/qingming-game';bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=R+'/public/assets/characters/QMSH-22.glb')
rig=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');rig.animation_data_clear()
# phase, lean, head turn, arm reach; normalized role-local time, explicit custom actions.
tracks={'brace':[[0,.05,0,.1],[.2,.24,-.1,1],[.75,.24,-.1,1],[1,0,0,0]],'steer':[[0,0,0,0],[.3,.20,-.35,1],[.65,.08,.2,.8],[1,0,0,.2]],'tow':[[0,.18,0,1],[.48,.20,-1.0,1],[.55,.20,-1.0,1],[.85,.05,0,.6],[1,0,0,0]],'call':[[0,0,0,0],[.25,.18,.15,1],[.75,.22,.1,1],[1,.05,0,.3]],'throw':[[0,.1,0,0],[.25,-.10,-.2,.2],[.45,.22,0,1],[.70,.1,0,1],[1,0,0,.4]],'receive':[[0,.08,0,0],[.4,-.16,.1,.2],[.7,.15,0,1],[1,.05,0,.8]],'lower':[[0,.15,0,1],[.4,.2,0,.7],[.85,.12,0,.3],[1,0,0,.1]]}
for name,keys in tracks.items():
 rig.animation_data_create();rig.animation_data.action=bpy.data.actions.new('HQ_'+name.upper())
 for phase,lean,turn,reach in keys:
  frame=round(phase*120)
  for prop,value in [('lean',lean),('turn',turn),('reach',reach)]:rig['hq_'+prop]=value;rig.keyframe_insert(data_path='["hq_'+prop+'"]',frame=frame)
  for b in rig.pose.bones:
   b.rotation_mode='XYZ';b.rotation_euler=(0,0,0)
   if 'Spine_1' in b.name:b.rotation_euler.x=lean
   if 'Head_0' in b.name:b.rotation_euler.y=turn
   if b.name in ['tripo::0_Right_Limb_0','bone_11']:b.rotation_euler.z=reach*(-.9 if b.name.startswith('tripo') else .9)
   if b.name in ['tripo::0_Right_Limb_1','bone_12']:b.rotation_euler.x=reach*-.6
   b.keyframe_insert(data_path='rotation_euler',frame=frame)
 rig.animation_data.action.use_fake_user=True
bpy.context.scene.render.fps=30;bpy.context.scene.frame_end=120;bpy.context.preferences.filepaths.save_version=0;bpy.ops.wm.save_as_mainfile(filepath=R+'/blender/hongqiao-cinema-actions.blend',compress=True)
json.dump({'sourceAsset':'QMSH-22','sourceFile':'assets/characters/QMSH-22.glb','authoredIn':'Blender','tracks':tracks,'armChains':[['tripo::0_Right_Limb_0','tripo::0_Right_Limb_1','tripo::0_Right_Limb_2'],['bone_11','bone_12','bone_13']]},open(R+'/src/hongqiao/cinema/actions.json','w'),indent=2)
print('HQ7_ACTIONS',list(tracks),flush=True)
