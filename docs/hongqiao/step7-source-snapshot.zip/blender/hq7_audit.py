import bpy,json
from mathutils import Vector
r='/Users/zhengrui/Documents/ChatGPT/3d 打印/qingming-game'
rows=[]
for o in bpy.data.objects:
 if o.type=='MESH' and any(x in o.name.lower() for x in ['cargo','barge','bridge']):
  pts=[o.matrix_world@Vector(v) for v in o.bound_box]
  rows.append({'name':o.name,'verts':len(o.data.vertices),'bounds':[[min(p[k] for p in pts) for k in range(3)],[max(p[k] for p in pts) for k in range(3)]]})
json.dump({'scenes':[s.name for s in bpy.data.scenes],'objects':rows},open(r+'/output/playwright/step7/native-audit.json','w'),ensure_ascii=False,indent=2)
print('HQ7_AUDIT',len(rows),flush=True)
