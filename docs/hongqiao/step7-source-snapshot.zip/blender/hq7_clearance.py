import bpy,json,math
from mathutils import Vector
from mathutils.bvhtree import BVHTree
R='/Users/zhengrui/Documents/ChatGPT/3d 打印/qingming-game';bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=R+'/public/assets/hongqiao/cinema/ship-hq.glb')
meshes=[o for o in bpy.context.scene.objects if o.type=='MESH'];mast=bpy.data.objects['mast_hq_pivot'];tris=json.load(open(R+'/public/assets/hongqiao/cinema/bridge-triangles.json'))
verts=[(v[0],-v[2],v[1]) for t in tris for v in t];faces=[(i,i+1,i+2) for i in range(0,len(verts),3)];bridge=BVHTree.FromPolygons(verts,faces,all_triangles=True)
proxy_positions=[[-2.6,2.58,0],[-8,.57,3.5],[-3.2,2.58,1],[-3.2,2.58,3.1]]
proxy_verts=[];proxy_faces=[]
for x,y,z in proxy_positions:
 start=len(proxy_verts);proxy_verts += [(x+dx,-z+dz,y+dy) for dx,dy,dz in [(-.85,0,-.85),(.85,0,-.85),(.85,0,.85),(-.85,0,.85),(-.85,2.4,-.85),(.85,2.4,-.85),(.85,2.4,.85),(-.85,2.4,.85)]]
 for f in [(0,1,2,3),(4,7,6,5),(0,4,5,1),(1,5,6,2),(2,6,7,3),(3,7,4,0)]:proxy_faces.append(tuple(start+i for i in f))
for low,high in [((1.5,.25,2.68),(4.1,2.15,2.87)),((-5.28,-.28,2.45),(-4.72,.28,2.9)),((-3.48,.17,2.55),(1.08,.33,3.63)),((-10.1,-5.2,-.15),(-8.3,-3.55,1.72))]:
 start=len(proxy_verts);proxy_verts += [(x,y,z) for x,y,z in [(low[0],low[1],low[2]),(high[0],low[1],low[2]),(high[0],high[1],low[2]),(low[0],high[1],low[2]),(low[0],low[1],high[2]),(high[0],low[1],high[2]),(high[0],high[1],high[2]),(low[0],high[1],high[2])]]
 for f in [(0,1,2,3),(4,7,6,5),(0,4,5,1),(1,5,6,2),(2,6,7,3),(3,7,4,0)]:proxy_faces.append(tuple(start+i for i in f))
def check(x,angle,yaw=0):
 root=bpy.data.objects['ship_hq_root'];root.rotation_mode='XYZ';root.rotation_euler.z=yaw;
 mast.rotation_mode='XYZ';mast.rotation_euler=(0,angle,0);bpy.context.view_layer.update();v=[];f=[]
 for o in meshes:
  o.data.calc_loop_triangles();start=len(v);v.extend([tuple(o.matrix_world@p.co+Vector((x,0,0))) for p in o.data.vertices]);f.extend([tuple(start+i for i in p.vertices) for p in o.data.loop_triangles])
 start=len(v);v.extend([(p[0]*math.cos(yaw)-p[1]*math.sin(yaw)+x,p[0]*math.sin(yaw)+p[1]*math.cos(yaw),p[2]) for p in proxy_verts]);f.extend([tuple(start+i for i in face) for face in proxy_faces]);body=BVHTree.FromPolygons(v,f)
 hits=bridge.overlap(body)
 return {'x':x,'angle':angle,'intersections':len(hits),'vertices':len(v),'faces':len(f),'bounds':[[min(p[k] for p in v) for k in range(3)],[max(p[k] for p in v) for k in range(3)]]}
ending=[check(11-i*.25,math.radians(87)) for i in range(109)]
intro=[check(10.3+.7*(i/80)**2*(3-2*i/80),math.radians(87)*min(1,i/64)**2*(3-2*min(1,i/64))) for i in range(81)]
approach=[check(14-3.7*(i/40)**2*(3-2*i/40),0,.04) for i in range(41)]+[check(10.3,0,.04*(1-i/20)) for i in range(21)]
report={'approach':approach,'method':'Full native hull/cabin/mast triangle BVH intersections against bridge triangles; four conservative 1.7x1.7x2.4 crew envelopes plus cloth, heel, stowed pole and steering oar envelopes included. Approach and heading adjustment also sampled. 0.25-unit translation samples and 81 mast swing samples.','ending':ending,'lowering':intro,'collisions':sum(s['intersections'] for s in ending+intro+approach)}
json.dump(report,open(R+'/output/playwright/step7/clearance.json','w'),indent=2);print('HQ7_CLEARANCE',report['collisions'],flush=True)
