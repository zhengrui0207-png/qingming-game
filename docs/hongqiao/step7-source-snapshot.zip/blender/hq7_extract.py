"""Isolated Step 7 source extraction. Never overwrite world, player, or the native master."""
import bpy,bmesh,json,math,os,hashlib
from mathutils import Vector
R='/Users/zhengrui/Documents/ChatGPT/3d 打印/qingming-game';OUT=R+'/public/assets/hongqiao/cinema';os.makedirs(OUT,exist_ok=True)
scene=bpy.context.scene;bpy.context.view_layer.update()
ship=[o for o in scene.objects if o.type=='MESH' and o.name.startswith(('QMV3_cargo_landmark_','QMV4_barge_detail_'))]
assert len(ship)==10
# Spatial fingerprints of the actual native triangles allow exact subtraction from the merged GLB.
triangles=[];bridge=[]
for o in ship:
 o.data.calc_loop_triangles()
 for f in o.data.loop_triangles:triangles.append([list(o.matrix_world@o.data.vertices[i].co) for i in f.vertices])
for o in scene.objects:
 if o.type=='MESH' and 'bridge' in o.name.lower() and not o.name.startswith('QMV4_static'):
  o.data.calc_loop_triangles()
  for f in o.data.loop_triangles:bridge.append([list(o.matrix_world@o.data.vertices[i].co) for i in f.vertices])
game=lambda p:[p[0],p[2],-p[1]]
json.dump({'shipTriangles':[[game(v) for v in tri] for tri in triangles],'bridgeTriangles':[[game(v) for v in tri] for tri in bridge]},open(OUT+'/native-triangles.json','w'))
# Preserve every low native hull/cabin piece. Remove complete connected islands of obsolete fixed rigging.
kept=[];removed=[]
for ob in ship:
 clone=ob.copy();clone.data=ob.data.copy();scene.collection.objects.link(clone);clone.name='hq_ship_'+ob.name
 bm=bmesh.new();bm.from_mesh(clone.data);bm.verts.ensure_lookup_table();seen=set();drop=[]
 for v in bm.verts:
  if v in seen:continue
  stack=[v];seen.add(v);component=[]
  while stack:
   q=stack.pop();component.append(q)
   for e in q.link_edges:
    n=e.other_vert(q)
    if n not in seen:seen.add(n);stack.append(n)
  if max((clone.matrix_world@q.co).z for q in component)>2.9:drop+=component
 removed.append({'node':ob.name,'removedVertices':len(drop),'originalVertices':len(bm.verts)})
 bmesh.ops.delete(bm,geom=drop,context='VERTS');bm.to_mesh(clone.data);bm.free()
 for v in clone.data.vertices:v.co=clone.matrix_world@v.co-Vector((18,3.168970108,0))
 clone.matrix_world.identity()
 if clone.data.polygons:kept.append(clone)
 else:bpy.data.objects.remove(clone,do_unlink=True)
# New articulation replaces only non-animatable old rigging; the hull remains the original geometry.
root=bpy.data.objects.new('ship_hq_root',None);scene.collection.objects.link(root)
for o in kept:o.parent=root
wood=next(m for m in bpy.data.materials if m.name=='QM_wood');cloth=next(m for m in bpy.data.materials if m.name=='QM_cloth')
def beam(name,a,b,r,mat,parent):
 a,b=Vector(a),Vector(b);bpy.ops.mesh.primitive_cylinder_add(vertices=12,radius=r,depth=(b-a).length,location=(a+b)/2);o=bpy.context.object;o.name=name;o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();o.data.materials.append(mat);o.parent=parent;return o
# Pivot lies on cargo platform; mast lowers toward stern, entirely above the cabin.
pivot=bpy.data.objects.new('mast_hq_pivot',None);scene.collection.objects.link(pivot);pivot.parent=root;pivot.location=(-5,0,2.85)
beam('mast_hq_timber',(0,0,0),(0,0,7.0),.13,wood,pivot)
beam('mast_hq_furled_sail',(-.5,0,5.3),(.5,0,5.3),.19,cloth,pivot)
beam('mast_hq_low_support',(1.8,0,2.45),(1.8,0,3.18),.14,wood,root)
# Author lowering keyframes at exact 21--25s, in native Blender Z-up coordinates.
pivot.rotation_mode='XYZ'
for frame,angle in [(0,0),(630,0),(750,math.radians(87)),(900,math.radians(87))]:pivot.rotation_euler.y=angle;pivot.keyframe_insert(data_path='rotation_euler',frame=frame)
scene.render.fps=30;scene.frame_start=0;scene.frame_end=900;scene.frame_set(0)
bpy.ops.object.select_all(action='DESELECT')
for o in [root,*kept,pivot,*pivot.children,*[o for o in root.children if o not in kept and o!=pivot]]:o.select_set(True)
bpy.context.view_layer.objects.active=root
bpy.ops.export_scene.gltf(filepath=OUT+'/ship-hq.glb',export_format='GLB',use_selection=True,export_animations=True,export_yup=True)
# Store only the authored ship in a dedicated native source, preserving original master on disk.
for o in list(scene.objects):
 if not o.select_get():bpy.data.objects.remove(o,do_unlink=True)
bpy.context.preferences.filepaths.save_version=0;bpy.ops.wm.save_as_mainfile(filepath=R+'/blender/hongqiao-cinema-ship.blend',compress=True)
json.dump({'sourceMeshes':10,'sourceTriangles':len(triangles),'bridgeTriangles':len(bridge),'removedFixedRig':removed,'pivotGame':[-5,2.85,0],'mastLength':7,'loweringFrames':[630,750]},open(R+'/output/playwright/step7/extraction.json','w'),indent=2)
print('HQ7_EXTRACTED',len(triangles),len(bridge),flush=True)
