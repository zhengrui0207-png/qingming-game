import * as THREE from 'three';
import actions from './actions.json';
import {sampleRole,clamp} from './timeline.js';
const V=(a)=>new THREE.Vector3(...a);
// Dedicated key poses from Blender + deterministic hand IK to the authored prop contact points.
export function createPerformer(library,id,parent,position,yaw=0){
 const visual=library.spawn('npc_hq_zhou');if(!visual)throw Error('Existing QMSH-22 boatman is unavailable');
 const root=visual.root;root.name=id;root.position.fromArray(position);root.rotation.y=yaw;parent.add(root);
 const bones=new Map(),base=new Map();root.traverse(o=>{if(o.isBone){bones.set(o.name,o);base.set(o,o.quaternion.clone());}if(o.name==='QMSH22_bamboo_pole')o.visible=false;if(o.isMesh){o.frustumCulled=false;o.castShadow=true;}});
 const chains=actions.armChains.map(names=>names.map(n=>bones.get(THREE.PropertyBinding.sanitizeNodeName(n)))).filter(c=>c.every(Boolean));
 if(chains.length!==2)throw Error('Cinematic performer needs both authored arm chains');
 const head=bones.get('tripoHead_0'),spine=bones.get('tripoSpine_1');
 function aim(chain,target){
  for(let repeat=0;repeat<5;repeat++)for(const joint of [chain[1],chain[0]]){
   root.updateMatrixWorld(true);const origin=joint.getWorldPosition(new THREE.Vector3()),end=chain[2].getWorldPosition(new THREE.Vector3());
   const from=end.sub(origin).normalize(),to=target.clone().sub(origin).normalize(),worldQ=new THREE.Quaternion().setFromUnitVectors(from,to),parentQ=joint.parent.getWorldQuaternion(new THREE.Quaternion());
   joint.quaternion.premultiply(parentQ.clone().invert().multiply(worldQ).multiply(parentQ));
  }
 }
 function pose(role,phase=0,targets=[]){
  for(const [b,q] of base)b.quaternion.copy(q);
  const [lean,turn,reach]=sampleRole(actions.tracks[role]??actions.tracks.brace,clamp(phase));
  const rotateWorld=(bone,axis,angle)=>{if(!bone)return;const parent=bone.parent.getWorldQuaternion(new THREE.Quaternion());bone.quaternion.premultiply(parent.clone().invert().multiply(new THREE.Quaternion().setFromAxisAngle(axis,angle)).multiply(parent));};
  rotateWorld(spine,new THREE.Vector3(1,0,0).applyQuaternion(root.getWorldQuaternion(new THREE.Quaternion())),lean);rotateWorld(head,new THREE.Vector3(0,1,0),turn);
  const defaults=[[-.3,1.1+reach*.6,.3+reach*.25],[.3,1.1+reach*.6,.3+reach*.25]];
  if(role==='tow'&&phase<.55){const stride=Math.sin(phase*24)*.28;for(const [name,sign] of [['tripo1_Right_Limb_0',1],['tripo0_Left_Limb_0',-1]])bones.get(name)?.rotateZ(sign*stride);}
  root.updateMatrixWorld(true);
  for(let i=0;i<chains.length;i++)aim(chains[i],targets[i]?V(targets[i]):root.localToWorld(V(defaults[i])));
 }
 return {root,pose,hand:i=>chains[i]?.[2].getWorldPosition(new THREE.Vector3()),getState:()=>({id,sourceAsset:visual.asset.id,position:root.getWorldPosition(new THREE.Vector3()).toArray(),armChains:chains.length,hands:chains.map(c=>c[2].getWorldPosition(new THREE.Vector3()).toArray())})};
}
