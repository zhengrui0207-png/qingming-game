// Local temporary voice, decoded before the intro starts. Shares the game's opt-in audio context.
export const CUES={intro:[[0,'intro_01'],[5,'intro_03'],[8,'intro_04'],[10,'intro_05'],[14,'intro_06'],[17,'intro_07'],[20,'intro_08a'],[21,'intro_08b'],[25,'intro_08c'],[27,'intro_09']],ending:[[0,'ending_01'],[12,'ending_02'],[16,'ending_03']]};
export async function createCinemaAudio(baseURL,getContext){
 const decoder=new OfflineAudioContext(1,1,22050),buffers=new Map(),errors=[];
 await Promise.all([...new Set(Object.values(CUES).flat().map(c=>c[1]))].map(async id=>{try{const r=await fetch(baseURL+'assets/hongqiao/cinema/audio/'+id+'.wav');if(!r.ok)throw Error('HTTP '+r.status);buffers.set(id,await decoder.decodeAudioData(await r.arrayBuffer()));}catch(e){errors.push(id+': '+e.message);console.warn('[Hongqiao voice unavailable]',id,e.message);}}));
 let kind=null,last=-.001,played=[],sources=new Set();
 function stop(){for(const source of sources){try{source.stop();}catch{}}sources.clear();}
 function voice(id,offset){const ctx=getContext(),buffer=buffers.get(id);if(!ctx||!buffer||offset>=buffer.duration)return;const source=ctx.createBufferSource(),gain=ctx.createGain();gain.gain.value=.72;source.buffer=buffer;source.connect(gain);gain.connect(ctx.destination);source.onended=()=>{sources.delete(source);gain.disconnect();};sources.add(source);source.start(0,Math.max(0,offset));played.push(id);}
 function wood(){const ctx=getContext();if(!ctx)return;const o=ctx.createOscillator(),g=ctx.createGain(),t=ctx.currentTime;o.type='triangle';o.frequency.setValueAtTime(150,t);o.frequency.exponentialRampToValueAtTime(60,t+.18);g.gain.setValueAtTime(.07,t);g.gain.exponentialRampToValueAtTime(.001,t+.23);o.connect(g);g.connect(ctx.destination);o.onended=()=>{sources.delete(o);g.disconnect();};sources.add(o);o.start();o.stop(t+.25);}
 return {begin(next){stop();kind=next;last=-.001;played=[];},update(t){for(const [at,id] of CUES[kind]??[])if(at>last&&at<=t)voice(id,t-at);if(kind==='intro'&&last<3&&t>=3)wood();last=t;},seek(t){stop();last=t;},stop,
 getState:()=>({loaded:buffers.size,errors,played,active:sources.size,context:getContext()?.state??'muted'})};
}
