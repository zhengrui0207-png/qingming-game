import {defaultState, normalizeState, reduceState} from './state.js';
export const SAVE_KEY = 'qingming:hongqiao:save';
export const BACKUP_KEY = SAVE_KEY + ':backup';
export const CORRUPT_KEY = SAVE_KEY + ':corrupt';
export const SAVE_KEYS = [SAVE_KEY, BACKUP_KEY, CORRUPT_KEY];
export function createProgressStore({config, storage, onError = e => console.error('[Hongqiao save]', e)}) {
  let state = defaultState(), status = {saved: false, kind: 'new', message: '尚无存档'}, verified = null;
  const listeners = new Set(), worldListeners = new Set(), errors = [];
  const report = e => { errors.push(String(e)); onError(e); };
  const decode = raw => normalizeState(JSON.parse(raw), config);
  function persist() {
    try {
      // Back up the last verified WHOLE snapshot, never a fragment of the new transaction.
      if (verified !== null) {
        storage.setItem(BACKUP_KEY, verified);
        if (storage.getItem(BACKUP_KEY) !== verified) throw Error('Backup readback mismatch');
      }
      const raw = JSON.stringify(state);
      storage.setItem(SAVE_KEY, raw);
      if (storage.getItem(SAVE_KEY) !== raw) throw Error('Save readback mismatch');
      decode(raw);
      verified = raw;
      status = {saved: true, kind: 'saved', message: '进度已保存'};
    } catch (e) {
      report(e);
      status = {saved: false, kind: 'save-failed', message: '保存失败：进度仍在本页内存中，请勿刷新；可重试保存。'};
    }
    return status.saved;
  }
  function load() {
    let damaged = false;
    for (const key of [SAVE_KEY, BACKUP_KEY]) {
      let raw;
      try {
        raw = storage.getItem(key);
        if (raw === null) continue;
        state = decode(raw);
        verified = JSON.stringify(state);
        const recovered = key === BACKUP_KEY;
        const migrated = JSON.parse(raw).schemaVersion !== state.schemaVersion || JSON.stringify(state) !== raw;
        if (recovered || migrated) {
          if (persist()) status = {saved: true, kind: recovered ? 'recovered' : 'migrated', message: recovered ? '主存档异常，已恢复上一份完整备份。' : '存档已迁移，原有进度已保留。'};
        } else status = {saved: true, kind: 'loaded', message: '已恢复存档'};
        return;
      } catch (e) {
        damaged = true;
        report(e);
        if (raw !== undefined && raw !== null) {
          try {storage.setItem(CORRUPT_KEY, JSON.stringify({key, raw, at: new Date().toISOString()}));} catch (backupError) {report(backupError);}
        }
      }
    }
    if (damaged) status = {saved: false, kind: 'unrecoverable', message: '存档无法读取，且无可用备份。本页使用默认状态，损坏记录已尝试保留。'};
  }
  load();
  const notify = event => {for (const fn of listeners) fn({state: structuredClone(state), status: {...status}, ...event});};
  function commit(next, action) {
    state = next;
    // Make collected instances disappear before persistence and UI notification.
    for (const fn of worldListeners) fn(structuredClone(state));
    persist();
    notify({action});
    return {ok: true, changed: true, saved: status.saved};
  }
  return {
    getState: () => structuredClone(state), getStatus: () => ({...status}), getErrors: () => [...errors],
    subscribe(fn) {listeners.add(fn); return () => listeners.delete(fn);},
    subscribeWorld(fn) {worldListeners.add(fn); return () => worldListeners.delete(fn);},
    dispatch(action) {
      const result = reduceState(state, action, config);
      if (!result.ok || !result.changed) return {...result, state: undefined, saved: status.saved};
      return commit(result.state, action);
    },
    retrySave() {persist(); notify({action: {type: 'retrySave'}}); return status.saved;},
    refreshUI() {notify({action: {type: 'refreshSnapshot'}});},
    // Used only by explicit development fixtures; not an NPC/quest settlement route.
    restoreFixture(snapshot) {return commit(normalizeState(snapshot, config), {type: 'developmentFixture'});},
  };
}
export function consumeResetURL({url, history, storage, development}) {
  const parsed = new URL(url);
  if (!parsed.searchParams.has('hqReset')) return {requested: false};
  parsed.searchParams.delete('hqReset');
  // Remove first, even if storage access fails: refreshing cannot repeat a reset.
  history.replaceState(history.state, '', parsed.pathname + parsed.search + parsed.hash);
  if (!development) return {requested: true, cleared: false};
  try {for (const key of SAVE_KEYS) storage.removeItem(key); return {requested: true, cleared: true};}
  catch (e) {return {requested: true, cleared: false, error: String(e)};}
}
