import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {DRACOLoader} from 'three/addons/loaders/DRACOLoader.js';
import {clone as cloneSkeleton} from 'three/addons/utils/SkeletonUtils.js';

const v=new THREE.Vector3(),q=new THREE.Quaternion();
const clamp=THREE.MathUtils.clamp;
function fitAnatomy(model,bounds){
 const bones=[];model.updateMatrixWorld(true);model.traverse(o=>{if(o.isBone)bones.push(o)});
 const h=bounds.max.y-bounds.min.y,c=bounds.getCenter(new THREE.Vector3());
 const positions=new Map(bones.map(b=>[b,b.getWorldPosition(new THREE.Vector3())]));
 const nearest=(y,z)=>bones.filter(b=>b.children.some(x=>x.isBone)).sort((a,b)=>{
  const cost=n=>{const p=positions.get(n);return Math.abs((p.y-bounds.min.y)/h-y)+Math.abs((p.z-c.z)/h-z)*2+Math.abs(p.x-c.x)/h*.4};return cost(a)-cost(b);
 })[0];
 const limb=b=>b?{bone:b,base:b.quaternion.clone(),axis:new THREE.Vector3(0,0,1).applyQuaternion(b.parent.getWorldQuaternion(new THREE.Quaternion()).invert())}:null;
 const thighs=[nearest(.50,-.07),nearest(.50,.07)];
 return {legs:thighs.map(b=>({hip:limb(b),knee:limb(b?.children.find(x=>x.isBone))})),spine:limb(nearest(.66,0))};
}
function rotatePart(part,angle){if(part)part.bone.quaternion.copy(part.base).premultiply(q.setFromAxisAngle(part.axis,angle));}

function bakeFarParts(low,full,bounds,bodyHeight,height){
 const materials=[];full.traverse(o=>{if(o.isMesh)materials.push(o.material)});
 const scale=height/bodyHeight,normalization=new THREE.Matrix4().makeRotationY(-Math.PI/2).multiply(new THREE.Matrix4().makeTranslation(-(bounds.max.x+bounds.min.x)*.5*scale,-bounds.min.y*scale,-(bounds.max.z+bounds.min.z)*.5*scale)).multiply(new THREE.Matrix4().makeScale(scale,scale,scale));
 const result=[];low.updateMatrixWorld(true);let index=0;
 low.traverse(o=>{if(!o.isMesh)return;const geometry=o.geometry.clone(),positions=geometry.attributes.position;
  o.skeleton?.update();for(let i=0;i<positions.count;i++){v.fromBufferAttribute(positions,i);if(o.isSkinnedMesh)o.applyBoneTransform(i,v);v.applyMatrix4(o.matrixWorld);positions.setXYZ(i,v.x,v.y,v.z)}
  const normals=geometry.attributes.normal;if(normals){const normalMatrix=new THREE.Matrix3().getNormalMatrix(o.matrixWorld);for(let i=0;i<normals.count;i++){v.fromBufferAttribute(normals,i).applyNormalMatrix(normalMatrix);normals.setXYZ(i,v.x,v.y,v.z)}}
  geometry.deleteAttribute('skinIndex');geometry.deleteAttribute('skinWeight');geometry.applyMatrix4(normalization);geometry.computeBoundingSphere();
  result.push({geometry,material:materials[index++]});
 });return result;
}

export async function loadNpcAssets(baseURL,onProgress=()=>{}){
 const [catalog,mapping]=await Promise.all(['catalog.json','npc-map.json'].map(async f=>{const r=await fetch(baseURL+'assets/characters/'+f);if(!r.ok)throw Error('人物清单加载失败');return r.json()}));
 const draco=new DRACOLoader().setDecoderPath(baseURL+'assets/draco/').setWorkerLimit(2);
 const loader=new GLTFLoader().setDRACOLoader(draco),templates=new Map(),failures=[];
 let cursor=0,done=0;
 await Promise.all(Array.from({length:3},async()=>{while(cursor<catalog.length){const asset=catalog[cursor++];try{
  const gltf=await loader.loadAsync(baseURL+asset.file);gltf.scene.updateMatrixWorld(true);
  const bounds=new THREE.Box3().setFromObject(gltf.scene),center=bounds.getCenter(new THREE.Vector3());
  let headTop=-Infinity;gltf.scene.traverse(o=>{if(o.isBone){o.getWorldPosition(v);if(Math.abs(v.z-center.z)<(bounds.max.y-bounds.min.y)*.22)headTop=Math.max(headTop,v.y)}});
  // Props may extend above the head; scale people by their body, not their staff.
  const height=bounds.max.y-bounds.min.y;
  const bodyHeight=Number.isFinite(headTop)?clamp(headTop-bounds.min.y+height*.065,height*.65,height):height;
  gltf.scene.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=true;o.frustumCulled=false;for(const m of Array.isArray(o.material)?o.material:[o.material]){m.envMapIntensity=.3;}}});
  let farParts=null;
  if(asset.lodFile){const low=await loader.loadAsync(baseURL+asset.lodFile);farParts=bakeFarParts(low.scene,gltf.scene,bounds,bodyHeight,asset.height)}
  templates.set(asset.id,{asset,gltf,bounds,bodyHeight,farParts});
 }catch(error){failures.push({assetId:asset.id,error:error.message});console.error('[NPC asset]',asset.id,error)}done++;onProgress(done,catalog.length)}}));
 draco.dispose();
 const byNPC=new Map(mapping.map(row=>[row.id,row]));
 function spawn(npcId){
  const assignment=byNPC.get(npcId),template=templates.get(assignment?.assetId);if(!template)return null;
  const {asset,gltf,bounds,bodyHeight}=template,root=new THREE.Group(),orientation=new THREE.Group(),model=cloneSkeleton(gltf.scene);
  const anatomy=asset.skins?fitAnatomy(model,bounds):null;
  root.name=npcId+' / '+asset.name;root.userData={npcId,assetId:asset.id,sourceStatus:asset.sourceStatus};
  orientation.rotation.y=-Math.PI/2;root.add(orientation);
  const fit=new THREE.Group();orientation.add(fit);fit.add(model);
  const scale=asset.height/bodyHeight;fit.scale.setScalar(scale);
  fit.position.set(-(bounds.max.x+bounds.min.x)*.5*scale,-bounds.min.y*scale,-(bounds.max.z+bounds.min.z)*.5*scale);
  const normalY=fit.position.y;
  const mixer=new THREE.AnimationMixer(model),clips=gltf.animations,actions=clips.map(c=>{const a=mixer.clipAction(c);a.play();a.enabled=true;a.setEffectiveWeight(0);return a});
  const idle=clips.findIndex(c=>/^idle$/i.test(c.name)),walk=clips.findIndex(c=>/^walk$/i.test(c.name)),occupation=clips.findIndex(c=>/occupation/i.test(c.name));
  let animationClock=0,walkWeight=0,lastUpdate=-Infinity,frames=0,currentClip='static';
  function update(time,dt,{walking=false,role='',phase=0,far=false,travelSpeed=1}={}){
   const seated=['骑马人','乘客'].includes(role);
   if(time-lastUpdate<(far?1/10:1/30)&&time>=lastUpdate)return;lastUpdate=time;frames++;
   animationClock+=Math.max(0,dt)*(walking?clamp(travelSpeed/.95,.4,1.9):1);
   if(actions.length){
    walkWeight=THREE.MathUtils.lerp(walkWeight,walking&&!seated?1:0,Math.min(1,dt*9));
    const working=!walking&&!seated&&occupation>=0&&((time+phase)%14)>5;
    for(let i=0;i<actions.length;i++){
     const weight=i===walk?walkWeight:i===(working?occupation:idle)?1-walkWeight:0;
     actions[i].setEffectiveWeight(weight);actions[i].time=(animationClock+phase)%clips[i].duration;
    }
    mixer.update(0);currentClip=walking&&!seated&&walk>=0?clips[walk].name:working?clips[occupation].name:idle>=0?clips[idle].name:'bind';
   }
   fit.position.y=normalY-(seated?asset.height*.48:0);
   if(seated&&anatomy){for(const leg of anatomy.legs){rotatePart(leg.hip,1.12);rotatePart(leg.knee,-1.25)}currentClip+=' + seated';}
   if(role==='船夫'&&anatomy){rotatePart(anatomy.spine,.04*Math.sin(time*3+phase));currentClip+=' + rowing';}
  }
  return {root,asset,update,state:()=>({npcId,assetId:asset.id,animated:clips.length>0,clip:currentClip,frames,sourceStatus:asset.sourceStatus,position:root.position.toArray(),scale:root.scale.toArray(),visible:root.visible}),dispose(){mixer.stopAllAction();mixer.uncacheRoot(model);root.removeFromParent()}};
 }
 return {spawn,catalog,mapping,failures,farParts:id=>templates.get(id)?.farParts,getState:()=>({requested:catalog.length,loaded:templates.size,failures,bytes:catalog.reduce((n,a)=>n+a.bytes+(a.lodBytes??0),0)})};
}

export function createNpcCrowd(scene,people,library,camera){
 const root=new THREE.Group();root.name='Tripo matched street residents';scene.add(root);
 const records=people.map((p,i)=>{const rec=library.spawn(`street-${String(i).padStart(3,'0')}`);if(rec)root.add(rec.root);return rec});
 const farPools=new Map(),matrix=new THREE.Matrix4(),rotation=new THREE.Quaternion(),size=new THREE.Vector3();
 for(const rec of records){if(!rec||farPools.has(rec.asset.id))continue;const parts=library.farParts?.(rec.asset.id);if(!parts?.length)continue;
  const capacity=records.filter(r=>r?.asset.id===rec.asset.id).length,meshes=parts.map(part=>{const mesh=new THREE.InstancedMesh(part.geometry,part.material,capacity);mesh.name='Distant '+rec.asset.id;mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);mesh.count=0;mesh.frustumCulled=false;mesh.castShadow=false;mesh.receiveShadow=true;root.add(mesh);return mesh});
  farPools.set(rec.asset.id,{meshes,cursor:0});
 }
 let visible=0,cinematicFocus=null;
 return {
  hide:i=>{if(records[i]){records[i].root.visible=false;records[i].screenVisible=false;}},
  setCamera:next=>{camera=next;},
  setCinematicFocus:next=>{cinematicFocus=next;},
  put(i,pose,walking,time,dt){
   const rec=records[i];if(!rec)return false;
   rec.root.position.set(pose.x,pose.y,pose.z);rec.root.rotation.y=pose.angle;rec.root.scale.setScalar(pose.scale||1);
   const distance=rec.root.position.distanceTo(camera.position);v.copy(rec.root.position);v.y+=1;v.project(camera);
   rec.screenVisible=distance<190&&v.z>-1&&v.z<1&&Math.abs(v.x)<1.3&&Math.abs(v.y)<1.4;
   if(cinematicFocus){const {from,to}=cinematicFocus,dx=to.x-from.x,dz=to.z-from.z,l=dx*dx+dz*dz,u=clamp(((pose.x-from.x)*dx+(pose.z-from.z)*dz)/l,0,1),near=Math.hypot(pose.x-from.x,pose.z-from.z)<7,corridor=Math.hypot(pose.x-from.x-dx*u,pose.z-from.z-dz*u)<1.65; if(near||corridor)rec.screenVisible=false;}
   const pool=farPools.get(rec.asset.id),far=distance>28&&!['骑马人','乘客'].includes(people[i].role)&&pool;
   rec.root.visible=rec.screenVisible&&!far;rec.lod=far?'distant':'full';
   if(rec.screenVisible){visible++;if(far){rotation.setFromAxisAngle(THREE.Object3D.DEFAULT_UP,pose.angle);size.setScalar(pose.scale||1);matrix.compose(rec.root.position,rotation,size);for(const mesh of pool.meshes)mesh.setMatrixAt(pool.cursor,matrix);pool.cursor++;}else rec.update(time,dt,{walking,role:people[i].role,phase:people[i].phase,far:distance>35,travelSpeed:people[i].travelSpeed})}
   return true;
  },
  done(){for(const pool of farPools.values()){for(const mesh of pool.meshes){mesh.count=pool.cursor;mesh.instanceMatrix.needsUpdate=true;}pool.cursor=0;}const n=visible;visible=0;return n;},
  getState:()=>({total:records.length,replaced:records.filter(Boolean).length,visible:records.filter(r=>r?.screenVisible).length,fullDetail:records.filter(r=>r?.root.visible).length,uniqueAssets:[...new Set(records.filter(Boolean).map(r=>r.asset.id))].length,staticInstances:records.filter(r=>r&&!r.asset.skins).length}),
  snapshot:()=>records.filter(Boolean).map(r=>({...r.state(),visible:r.screenVisible,lod:r.lod}))
 };
}
